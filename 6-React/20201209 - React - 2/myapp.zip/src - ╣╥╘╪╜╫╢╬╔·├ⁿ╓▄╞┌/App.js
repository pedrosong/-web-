import { Component } from "react";
import Child from "./child";

class App extends Component {
  render() {
    return <>
        <Child />  
    </>
  }
}

export default App;
