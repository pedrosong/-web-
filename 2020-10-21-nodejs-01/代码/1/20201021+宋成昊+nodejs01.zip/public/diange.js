let dahai = document.querySelector('h1');
dahai.onclick = function() {
    console.log('大海，给我唱！');
}