let rootdata = {
  React:["Component","Hooks","state&props"],
  Router:["Browsers","Hash","NavLink"],
  Redux:["reducer","action","dispatch"]
}; 

export default rootdata;